from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Generator


@contextmanager
def _connection(database_path: Path) -> Generator[sqlite3.Connection, None, None]:
    connection = sqlite3.connect(database_path)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def _history_rows(connection: sqlite3.Connection, product_id: str) -> list[dict]:
    rows = connection.execute(
        "SELECT observed_at, price FROM price_history WHERE product_id = ? ORDER BY observed_at",
        (product_id,),
    ).fetchall()
    return [{"date": row["observed_at"], "price": float(row["price"])} for row in rows]


def _with_history(connection: sqlite3.Connection, row: sqlite3.Row) -> dict:
    product = dict(row)
    points = _history_rows(connection, product["id"])
    prices = [point["price"] for point in points]
    recent_cutoff = (datetime.now(timezone.utc) - timedelta(days=30)).date().isoformat()
    recent_prices = [point["price"] for point in points if point["date"] >= recent_cutoff]
    product.update({
        "history": prices,
        "history_points": points,
        "historical_low": min(prices) if prices else None,
        "historical_high": max(prices) if prices else None,
        "historical_average": sum(prices) / len(prices) if prices else None,
        "recent_average": sum(recent_prices) / len(recent_prices) if recent_prices else None,
    })
    return product


def initialize_database(database_path: Path, catalog_path: Path, watchlist_path: Path | None = None) -> None:
    database_path.parent.mkdir(parents=True, exist_ok=True)
    with _connection(database_path) as connection:
        connection.executescript("""
            CREATE TABLE IF NOT EXISTS products (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                brand TEXT NOT NULL,
                category TEXT NOT NULL,
                seller TEXT NOT NULL,
                rating REAL NOT NULL,
                reviews INTEGER NOT NULL,
                spec_level REAL NOT NULL,
                current_price REAL NOT NULL CHECK (current_price > 0),
                list_price REAL NOT NULL CHECK (list_price > 0),
                image TEXT NOT NULL,
                description TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS price_history (
                id INTEGER PRIMARY KEY,
                product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
                observed_at TEXT NOT NULL,
                price REAL NOT NULL CHECK (price > 0),
                source TEXT NOT NULL DEFAULT 'demo',
                UNIQUE (product_id, observed_at)
            );
            CREATE INDEX IF NOT EXISTS idx_price_history_product_date
                ON price_history(product_id, observed_at);
            CREATE TABLE IF NOT EXISTS watchlist (
                product_id TEXT PRIMARY KEY REFERENCES products(id) ON DELETE CASCADE,
                added_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS activity (
                id INTEGER PRIMARY KEY,
                product_id TEXT REFERENCES products(id) ON DELETE SET NULL,
                action TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
        """)
        product_count = connection.execute("SELECT COUNT(*) FROM products").fetchone()[0]
        if product_count:
            return

        catalog = json.loads(catalog_path.read_text(encoding="utf-8"))
        observed_at = datetime.now(timezone.utc)
        for product in catalog:
            connection.execute(
                """INSERT INTO products
                   (id, name, brand, category, seller, rating, reviews, spec_level,
                    current_price, list_price, image, description)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    product["id"], product["name"], product["brand"], product["category"],
                    product.get("seller", "Demo seller"), product.get("rating", 4.0),
                    product.get("reviews", 0), product.get("spec_level", 0.5),
                    product["current_price"], product.get("list_price") or product["current_price"],
                    product.get("image", ""), product.get("description", ""),
                ),
            )
            history = product.get("history", [])
            for index, price in enumerate(history):
                timestamp = observed_at - timedelta(days=7 * (len(history) - index - 1))
                connection.execute(
                    "INSERT INTO price_history (product_id, observed_at, price, source) VALUES (?, ?, ?, 'demo')",
                    (product["id"], timestamp.isoformat(timespec="seconds"), price),
                )

        if watchlist_path and watchlist_path.exists():
            try:
                saved_ids = json.loads(watchlist_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                saved_ids = []
            for product_id in saved_ids:
                connection.execute(
                    "INSERT OR IGNORE INTO watchlist (product_id, added_at) VALUES (?, ?)",
                    (product_id, observed_at.isoformat(timespec="seconds")),
                )


def list_products(database_path: Path) -> list[dict]:
    with _connection(database_path) as connection:
        rows = connection.execute("SELECT * FROM products ORDER BY name").fetchall()
        return [_with_history(connection, row) for row in rows]


def get_product(database_path: Path, product_id: str) -> dict | None:
    with _connection(database_path) as connection:
        row = connection.execute("SELECT * FROM products WHERE id = ?", (product_id,)).fetchone()
        return _with_history(connection, row) if row else None


def get_price_history(database_path: Path, product_id: str) -> list[dict]:
    with _connection(database_path) as connection:
        exists = connection.execute("SELECT 1 FROM products WHERE id = ?", (product_id,)).fetchone()
        return _history_rows(connection, product_id) if exists else []


def find_similar_products(database_path: Path, product_id: str, limit: int = 4) -> list[dict]:
    with _connection(database_path) as connection:
        product_row = connection.execute("SELECT * FROM products WHERE id = ?", (product_id,)).fetchone()
        if not product_row:
            return []
        product = dict(product_row)
        rows = connection.execute(
            """SELECT * FROM products
               WHERE id != ? AND category = ?
                 AND current_price BETWEEN ? AND ?
                 AND rating >= ?
               ORDER BY (brand = ?) DESC,
                        ABS(current_price - ?) ASC,
                        ABS(rating - ?) ASC
               LIMIT ?""",
            (
                product_id, product["category"], product["current_price"] * 0.5,
                product["current_price"] * 2.0, max(1, product["rating"] - 0.8),
                product["brand"], product["current_price"], product["rating"], limit,
            ),
        ).fetchall()
        return [_with_history(connection, row) for row in rows]


def list_watchlist(database_path: Path) -> list[dict]:
    with _connection(database_path) as connection:
        rows = connection.execute(
            """SELECT products.*, watchlist.added_at
               FROM watchlist JOIN products ON products.id = watchlist.product_id
               ORDER BY watchlist.added_at DESC"""
        ).fetchall()
        return [_with_history(connection, row) for row in rows]


def watchlist_ids(database_path: Path) -> set[str]:
    with _connection(database_path) as connection:
        return {row[0] for row in connection.execute("SELECT product_id FROM watchlist")}


def save_to_watchlist(database_path: Path, product_id: str) -> bool:
    with _connection(database_path) as connection:
        exists = connection.execute("SELECT 1 FROM products WHERE id = ?", (product_id,)).fetchone()
        if not exists:
            return False
        connection.execute(
            "INSERT OR IGNORE INTO watchlist (product_id, added_at) VALUES (?, ?)",
            (product_id, datetime.now(timezone.utc).isoformat(timespec="seconds")),
        )
        return True


def remove_from_watchlist(database_path: Path, product_id: str) -> None:
    with _connection(database_path) as connection:
        connection.execute("DELETE FROM watchlist WHERE product_id = ?", (product_id,))


def record_activity(database_path: Path, product_id: str, action: str) -> None:
    with _connection(database_path) as connection:
        connection.execute(
            "INSERT INTO activity (product_id, action, created_at) VALUES (?, ?, ?)",
            (product_id, action, datetime.now(timezone.utc).isoformat(timespec="seconds")),
        )


def recent_activity(database_path: Path, limit: int = 8) -> list[dict]:
    with _connection(database_path) as connection:
        rows = connection.execute(
            """SELECT activity.action, activity.created_at, products.id, products.name,
                      products.brand, products.category, products.current_price, products.image
               FROM activity LEFT JOIN products ON products.id = activity.product_id
               ORDER BY activity.created_at DESC LIMIT ?""",
            (limit,),
        ).fetchall()
        return [dict(row) for row in rows]