import json
import unittest
from pathlib import Path

from app import app, DATA_DIR


class DealSenseApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        app.config.update(TESTING=True)
        cls.client = app.test_client()

    def test_health_includes_training_metrics(self):
        response = self.client.get("/api/health")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json["status"], "ok")
        self.assertIn("mae", response.json["model"]["metrics"])
        self.assertEqual(len(response.json["model"]["metrics"]["model_comparison"]), 2)

    def test_sample_product_analysis_returns_explanations(self):
        response = self.client.post("/api/analyze", json={"product_id": "auraloop-studio-one"})
        self.assertEqual(response.status_code, 200)
        self.assertIn(response.json["status"], {"Strong Deal", "Fair Price", "Slightly Expensive", "Overpriced"})
        self.assertEqual(len(response.json["explanations"]), 3)
        self.assertEqual(len(response.json["history"]), 12)
        self.assertLess(response.json["price_difference"], 0)

    def test_product_detail_history_and_similar_endpoints(self):
        detail = self.client.get("/api/products/auraloop-studio-one")
        history = self.client.get("/api/products/auraloop-studio-one/history")
        similar = self.client.get("/api/products/auraloop-studio-one/similar")
        self.assertEqual(detail.status_code, 200)
        self.assertIn("estimated_fair_price", detail.json)
        self.assertEqual(len(history.json["history"]), 12)
        self.assertEqual(history.json["historical_low"], min(point["price"] for point in history.json["history"]))
        self.assertTrue(any(item["id"] == "soundcore-mini-pro" for item in similar.json))
        self.assertEqual(self.client.get("/api/products/missing").status_code, 404)

    def test_search_dashboard_and_compare_endpoints(self):
        search = self.client.get("/api/products?q=soundcore")
        dashboard = self.client.get("/api/dashboard")
        comparison = self.client.post("/api/compare", json={
            "product_ids": ["auraloop-studio-one", "soundcore-mini-pro"],
        })
        self.assertEqual([item["brand"] for item in search.json], ["Soundcore"])
        self.assertEqual(dashboard.status_code, 200)
        self.assertEqual(dashboard.json["catalog_size"], 8)
        self.assertIn("potential_savings", dashboard.json["summary"])
        self.assertEqual(len(comparison.json), 2)
        self.assertEqual(self.client.post("/api/compare", json={"product_ids": ["missing", "soundcore-mini-pro"]}).status_code, 404)
        self.assertEqual(self.client.post("/api/compare", json={"product_ids": ["soundcore-mini-pro", "soundcore-mini-pro"]}).status_code, 400)

    def test_collection_watchlist_post_updates_dashboard_metrics(self):
        already_saved = any(
            item["product"]["id"] == "soundcore-mini-pro"
            for item in self.client.get("/api/watchlist").json
        )
        try:
            saved = self.client.post("/api/watchlist", json={"product_id": "soundcore-mini-pro"})
            self.assertEqual(saved.status_code, 200)
            watchlist = self.client.get("/api/watchlist").json
            self.assertTrue(any(item["product"]["id"] == "soundcore-mini-pro" for item in watchlist))
            dashboard = self.client.get("/api/dashboard").json
            self.assertEqual(dashboard["summary"]["products_tracked"], len(watchlist))
            self.assertGreaterEqual(dashboard["summary"]["potential_savings"], 0)
        finally:
            if not already_saved:
                self.client.delete("/api/watchlist/soundcore-mini-pro")

    def test_custom_product_and_invalid_price(self):
        valid = self.client.post("/api/analyze", json={
            "name": "Test headphones",
            "brand": "Other",
            "category": "Audio",
            "current_price": 4500,
            "list_price": 5999,
            "rating": 4.2,
        })
        self.assertEqual(valid.status_code, 200)
        self.assertEqual(valid.json["product"]["id"], "custom")
        self.assertFalse(valid.json["has_history"])
        self.assertIsNone(valid.json["recent_median"])
        invalid = self.client.post("/api/analyze", json={"current_price": 0})
        self.assertEqual(invalid.status_code, 400)
        invalid_list_price = self.client.post("/api/analyze", json={"current_price": 4500, "list_price": -1})
        self.assertEqual(invalid_list_price.status_code, 400)

    def test_watchlist_persists_and_can_remove_sample(self):
        path = DATA_DIR / "watchlist.json"
        original = path.read_text(encoding="utf-8") if path.exists() else None
        self.addCleanup(self._restore_watchlist, path, original)
        added = self.client.post("/api/watchlist/auraloop-studio-one")
        self.assertEqual(added.status_code, 200)
        self.assertEqual(len(self.client.get("/api/watchlist").json), 1)
        removed = self.client.delete("/api/watchlist/auraloop-studio-one")
        self.assertEqual(removed.status_code, 200)
        self.assertEqual(self.client.get("/api/watchlist").json, [])

    @staticmethod
    def _restore_watchlist(path: Path, content: str | None):
        if content is None:
            path.unlink(missing_ok=True)
        else:
            json.loads(content)
            path.write_text(content, encoding="utf-8")


if __name__ == "__main__":
    unittest.main()