import unittest

from pricing import calculate_deal_score, classify_deal


class PricingLogicTests(unittest.TestCase):
    def test_category_thresholds_use_fair_price_relationship(self):
        self.assertEqual(classify_deal(90, 100)[0], "Strong Deal")
        self.assertEqual(classify_deal(103, 100)[0], "Fair Price")
        self.assertEqual(classify_deal(112, 100)[0], "Slightly Expensive")
        self.assertEqual(classify_deal(120, 100)[0], "Overpriced")

    def test_score_uses_history_and_rating(self):
        score, explanation = calculate_deal_score(70, 100, 4.6, [70, 90, 100])
        self.assertGreaterEqual(score, 0)
        self.assertLessEqual(score, 100)
        self.assertIn("historical-average", explanation)

    def test_score_discloses_missing_history(self):
        _, explanation = calculate_deal_score(90, 100, 4.0, [])
        self.assertIn("Without price history", explanation)


if __name__ == "__main__":
    unittest.main()