from __future__ import annotations

from statistics import fmean


STRONG_DEAL_MIN_DIFFERENCE = 0.10
FAIR_PRICE_MIN_DIFFERENCE = -0.06
SLIGHTLY_EXPENSIVE_MIN_DIFFERENCE = -0.18


def classify_deal(current_price: float, fair_price: float) -> tuple[str, float]:
    difference = (fair_price - current_price) / fair_price if fair_price > 0 else 0
    if difference >= STRONG_DEAL_MIN_DIFFERENCE:
        category = "Strong Deal"
    elif difference >= FAIR_PRICE_MIN_DIFFERENCE:
        category = "Fair Price"
    elif difference >= SLIGHTLY_EXPENSIVE_MIN_DIFFERENCE:
        category = "Slightly Expensive"
    else:
        category = "Overpriced"
    return category, difference


def calculate_deal_score(
    current_price: float,
    fair_price: float,
    rating: float,
    history: list[float],
) -> tuple[int, str]:
    _, fair_difference = classify_deal(current_price, fair_price)
    fair_component = _clamp(50 + fair_difference * 250)
    rating_component = _clamp((rating - 3) / 2 * 100)
    if history:
        historical_average = fmean(history)
        historical_low = min(history)
        historical_high = max(history)
        average_difference = (historical_average - current_price) / historical_average if historical_average else 0
        average_component = _clamp(50 + average_difference * 220)
        low_component = 100 if historical_high == historical_low else _clamp(
            (historical_high - current_price) / (historical_high - historical_low) * 100
        )
        score = round(0.5 * fair_component + 0.2 * average_component + 0.2 * low_component + 0.1 * rating_component)
        explanation = "Score weights the fair-price gap (50%), historical-average comparison (20%), price position in the recorded range (20%), and rating (10%)."
    else:
        score = round(0.8 * fair_component + 0.2 * rating_component)
        explanation = "Without price history, the score uses the fair-price gap (80%) and rating (20%)."
    return max(0, min(100, score)), explanation


def build_explanations(
    current_price: float,
    fair_price: float,
    rating: float,
    history: list[float],
) -> list[dict[str, str]]:
    factors: list[dict[str, str]] = []
    fair_difference = (fair_price - current_price) / fair_price if fair_price else 0
    if fair_difference >= 0:
        factors.append({
            "label": "Below estimated fair price",
            "value": f"Current price is {fair_difference:.1%} below the model estimate.",
            "tone": "positive",
        })
    else:
        factors.append({
            "label": "Above estimated fair price",
            "value": f"Current price is {abs(fair_difference):.1%} above the model estimate.",
            "tone": "caution",
        })

    if history:
        historical_average = fmean(history)
        historical_low = min(history)
        if current_price <= historical_low * 1.03:
            factors.append({
                "label": "Near the recorded low",
                "value": f"Within 3% of the lowest stored price ({historical_low:,.0f}).",
                "tone": "positive",
            })
        elif current_price > historical_average:
            factors.append({
                "label": "Above the historical average",
                "value": f"Current price is {(current_price - historical_average) / historical_average:.1%} above the stored average.",
                "tone": "caution",
            })
        else:
            factors.append({
                "label": "Below the historical average",
                "value": f"Current price is {(historical_average - current_price) / historical_average:.1%} below the stored average.",
                "tone": "positive",
            })
    else:
        factors.append({
            "label": "No stored price history",
            "value": "Historical comparisons are unavailable for this listing.",
            "tone": "neutral",
        })

    if rating >= 4.4:
        factors.append({"label": "Strong product rating", "value": f"Rated {rating:.1f} out of 5.", "tone": "positive"})
    elif rating < 3.7:
        factors.append({"label": "Lower product rating", "value": f"Rated {rating:.1f} out of 5.", "tone": "caution"})
    else:
        factors.append({"label": "Product rating", "value": f"Rated {rating:.1f} out of 5.", "tone": "neutral"})
    return factors


def _clamp(value: float) -> float:
    return max(0, min(100, value))