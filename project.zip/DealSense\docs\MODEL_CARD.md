# Model card: DealSense price estimate

## Intended use

The model demonstrates a product-price regression workflow and feeds a local decision-support prototype. It is not intended to set prices, make purchase decisions for users, or represent live market conditions.

## Model and inputs

The candidate estimator is a scikit-learn `RandomForestRegressor` inside a preprocessing pipeline. It predicts a fair-price estimate using category, brand, product rating, review count, normalized specification level and original/list price. Training compares it with a mean-price baseline on the same holdout and saves the lower-MAE candidate. The demo uses INR.

Training data is generated reproducibly by `ml/price_model.py` with NumPy seed `20260930`. The 1,100 generated rows model broad category/brand price levels with rating, review volume, specifications, and small random variation. An 80/20 random holdout split reports MAE, RMSE, and R-squared in `reports/model_metrics.json`.

## Deal interpretation

Let `d = (estimated fair price - current price) / estimated fair price`. Deal labels use backend-owned thresholds:

- Strong Deal: `d >= 0.10`
- Fair Price: `-0.06 <= d < 0.10`
- Slightly Expensive: `-0.18 <= d < -0.06`
- Overpriced: `d < -0.18`

With price history, the 0–100 score weights the fair-price gap (50%), current price versus historical average (20%), position in the recorded low/high range (20%) and rating (10%). Without history it uses the fair-price gap (80%) and rating (20%). The UI displays the applicable formula.

The separate displayed-discount check compares the listed-price discount with savings versus the stored recent average. It flags a potential mismatch when the displayed discount is at least 20% and exceeds recent-average savings by at least 15 percentage points. The copy describes the comparison neutrally and does not infer retailer intent.

## Limitations and risks

- All training observations and catalog history are synthetic demonstration data; they are not collected from a retailer or a real market.
- Holdout metrics measure fit to that generated distribution only. They are not evidence of real-world predictive accuracy.
- Product attributes, seller, bundles, taxes, region, stock, warranty and promotion details are simplified or absent.
- The model does not fetch current prices. Demo histories are weekly snapshots created for this prototype.
- A model estimate and deal score are uncertain signals, not guarantees or a recommendation to buy.
- Real deployment would need lawful, representative, time-stamped pricing data, time-aware evaluation, drift monitoring and appropriate disclosure.

## Reproducibility

Install the compatible dependencies from `requirements.txt` and run `python -m tools.train_model`. The command recreates the synthetic training CSV, fitted artifact and metrics JSON.