const state = { products: [], selectedId: null, result: null, toastTimer: null, dashboard: null, dashboardRequest: 0 };
const currency = new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 });
const byId = (id) => document.getElementById(id);

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]);
}

function money(value) {
  return currency.format(Number(value) || 0);
}

function showToast(message) {
  const toast = byId("toast");
  toast.textContent = message;
  toast.classList.add("is-visible");
  clearTimeout(state.toastTimer);
  state.toastTimer = setTimeout(() => toast.classList.remove("is-visible"), 2600);
}

async function requestJson(url, options = {}) {
  const response = await fetch(url, { headers: { "Content-Type": "application/json" }, ...options });
  let data = {};
  try { data = await response.json(); } catch { data = {}; }
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status}). Please try again.`);
  if (!data || typeof data !== "object") throw new Error("The service returned an unreadable response. Please try again.");
  return data;
}

function imageTag(url, alt, className = "") {
  return `<img class="${className}" src="${escapeHtml(url || "")}" alt="${escapeHtml(alt)}" loading="lazy" onerror="this.onerror=null;this.src='/static/assets/product-placeholder.svg'">`;
}

function illustrationMarkup(symbol, className = "") {
  return `<span class="mini-illustration ${className}" aria-hidden="true"><svg class="illustration-symbol" viewBox="0 0 64 64"><use href="#ds-illustration-${escapeHtml(symbol)}"></use></svg></span>`;
}

function emptyStateMarkup(symbol, title, description, className = "") {
  return `<div class="empty-state illustrated-empty ${className}">${illustrationMarkup(symbol)}<span class="illustrated-empty-copy"><b>${escapeHtml(title)}</b><span>${escapeHtml(description)}</span></span></div>`;
}

function renderCatalog() {
  byId("catalog-count").textContent = `${state.products.length} PRODUCTS`;
  const cardMarkup = (product, index) => `
    <button class="product-tile" type="button" data-product-id="${escapeHtml(product.id)}" aria-label="Analyze ${escapeHtml(product.name)}">
      ${imageTag(product.image, product.name)}
      <span class="tile-content"><small>${escapeHtml(product.category.toUpperCase())} / ${String(index + 1).padStart(2, "0")}</small><b>${escapeHtml(product.name)}</b>
        <span class="tile-price"><strong>${money(product.current_price)}</strong><span>${product.status === "Strong Deal" ? `${product.deal_score}/100 · Strong deal` : "Analyze price ↗"}</span></span>
      </span>
    </button>`;
  byId("popular-product-grid").innerHTML = state.products.slice(0, 4).map(cardMarkup).join("") || emptyStateMarkup("box", "No products available", "Try again after product data has loaded.");
  const deals = state.products.filter((product) => product.status === "Strong Deal").sort((a, b) => b.deal_score - a.deal_score).slice(0, 4);
  byId("good-deal-grid").innerHTML = deals.length ? deals.map(cardMarkup).join("") : emptyStateMarkup("tag", "No strong-deal signals yet", "The current catalog has no products below the strong-deal threshold.");
}

function resultMarkup(result) {
  const product = result.product;
  const below = result.difference_pct >= 0;
  const statusSentence = {
    "Strong Deal": "Pricing sits meaningfully below the model estimate.",
    "Fair Price": "Today's price is close to the estimated typical range.",
    "Slightly Expensive": "This price is somewhat above the model estimate.",
    "Overpriced": "This price is well above the model estimate.",
  }[result.status];
  const reasons = result.explanations.map((factor) => `
    <div class="why-row"><span class="factor-mark ${factor.tone === "caution" ? "caution" : factor.tone === "positive" ? "positive" : "neutral"}" aria-hidden="true">${factor.tone === "positive" ? "✓" : factor.tone === "caution" ? "×" : "–"}</span>
      <span><b>${escapeHtml(factor.label)}</b><small>${escapeHtml(factor.value)}</small></span></div>`).join("");
  const similar = result.comparables.length ? result.comparables.map((item) => `
    <button class="similar-card" type="button" data-product-id="${escapeHtml(item.id)}">
      ${imageTag(item.image, item.name)}<span class="similar-copy"><b>${escapeHtml(item.name)}</b><small>${escapeHtml(item.brand)} · ${Number(item.rating).toFixed(1)} ★ · ${item.deal_score}/100</small></span><span class="similar-price">${money(item.current_price)}<small>${escapeHtml(item.status)}</small></span>
    </button>`).join("") : emptyStateMarkup("box", "No close matches", "There are no similar catalog products within this price range.");
  const weakDiscount = result.weak_discount ? `
    <aside class="weak-discount"><span class="alert-icon" aria-hidden="true">!</span><span><b>Displayed discount, meet recent pricing</b>
      <p>${escapeHtml(result.discount_reality.explanation)}</p></span></aside>` : "";
  const discount = result.discount_reality;
  return `
    <div class="analysis-top">
      <article class="product-feature">
        <div class="feature-image">${imageTag(product.image, product.name)}</div>
        <button class="save-button ${product.saved ? "is-saved" : ""}" id="save-product" type="button" aria-label="${product.saved ? "Remove from" : "Add to"} watchlist" title="${product.saved ? "Remove from" : "Add to"} watchlist">${product.saved ? "★" : "☆"}</button>
        <div class="feature-copy"><span class="category-tag">${escapeHtml(product.category)}</span><h2>${escapeHtml(product.name)}</h2>
          <p class="feature-description">${escapeHtml(product.description || "User-entered listing")}</p>
          <div class="seller-line"><span class="seller-stars">★</span> ${Number(product.rating).toFixed(1)} <span>·</span> ${Number(product.reviews || 0).toLocaleString("en-IN")} reviews <span>·</span> ${escapeHtml(product.brand)} <span>·</span> ${escapeHtml(product.seller || "Your listing")}</div></div>
      </article>
      <article class="deal-card"><span class="small-label">THE READ / 01</span><h2>${escapeHtml(result.status)}</h2><p>${escapeHtml(statusSentence)}</p>
        <span class="deal-difference ${below ? "" : "negative"}">${below ? "↓" : "↑"} ${Math.abs(result.difference_pct)}% vs fair price</span></article>
      <article class="score-card"><span class="score-illustration" aria-hidden="true"><i class="score-orbit"></i><svg class="score-coin-art" viewBox="0 0 64 64"><use href="#ds-illustration-coin"></use></svg><svg class="score-spark-art" viewBox="0 0 64 64"><use href="#ds-illustration-spark"></use></svg><svg class="score-tag-art" viewBox="0 0 64 64"><use href="#ds-illustration-tag"></use></svg></span><span class="small-label">DEAL SCORE</span><div class="score-dial" style="--score:${result.deal_score}" role="img" aria-label="Deal score ${result.deal_score} out of 100"><span class="score-value">${result.deal_score}<small>/100</small></span></div><span class="score-caption">${escapeHtml(result.status)}</span></article>
    </div>
    <div class="metric-row">
      <article class="metric-card"><span class="metric-label">CURRENT PRICE</span><strong class="metric-value">${money(result.current_price)}</strong><span class="metric-foot">Original / MRP ${money(product.list_price || result.current_price)}</span></article>
      <article class="metric-card fair-metric"><span class="metric-label">ESTIMATED FAIR PRICE</span><strong class="metric-value">${money(result.estimated_fair_price)}</strong><span class="metric-foot">Model estimate · ${below ? `${Math.abs(result.difference_pct)}% below` : `${Math.abs(result.difference_pct)}% above`}</span></article>
      <article class="metric-card"><span class="metric-label">PRICE DIFFERENCE</span><strong class="metric-value">${money(Math.abs(result.price_difference))}</strong><span class="metric-foot">${below ? "Below" : "Above"} estimated fair price</span></article>
    </div>
    <div class="analysis-bottom">
      <article class="chart-card"><div class="card-heading"><div><h3>Price history</h3><p>${result.has_history ? "Stored observations · demonstration data" : "No history supplied for this listing"}</p></div><span class="chart-heading-tools"><span class="history-art" aria-hidden="true"><svg viewBox="0 0 64 64"><use href="#ds-illustration-chart"></use></svg></span><span class="range-label">${result.history.length} POINTS</span></span></div>
        <div class="chart-wrap"><canvas id="price-chart" aria-label="Price history chart" role="img"></canvas></div>
        <div class="history-stats"><span>Low <b>${result.historical_low === null ? "—" : money(result.historical_low)}</b></span><span>Average <b>${result.historical_average === null ? "—" : money(result.historical_average)}</b></span><span>High <b>${result.historical_high === null ? "—" : money(result.historical_high)}</b></span><span>Current <b>${money(result.current_price)}</b></span></div></article>
      <article class="why-card"><div class="card-heading"><div><h3>Why did DealSense give this result?</h3><p>Factors calculated from the listing and stored history</p></div><span class="range-label">EXPLAINED</span></div><div class="why-list">${reasons}</div><p class="score-explanation">${escapeHtml(result.score_explanation)}</p></article>
    </div>
    <section class="discount-panel"><div class="discount-heading"><div><p class="eyebrow">REFERENCE PRICE CHECK</p><h3>Is the discount really that good?</h3></div><span class="discount-illustration" aria-hidden="true"><svg class="discount-tag-art" viewBox="0 0 64 64"><use href="#ds-illustration-tag"></use></svg><svg class="discount-search-art" viewBox="0 0 64 64"><use href="#ds-illustration-search"></use></svg></span><span class="range-label">MRP IS NOT HISTORY</span></div>
      <div class="discount-metrics"><div><small>Original / MRP</small><b>${money(discount.original_price)}</b></div><div><small>Displayed discount</small><b>${discount.displayed_discount_pct}%</b></div><div><small>Recent average</small><b>${discount.recent_average_price === null ? "—" : money(discount.recent_average_price)}</b></div><div><small>Current price</small><b>${money(discount.current_price)}</b></div><div><small>Historical low</small><b>${discount.historical_low === null ? "—" : money(discount.historical_low)}</b></div><div><small>Saving vs recent average</small><b>${discount.actual_saving_pct === null ? "—" : `${discount.actual_saving_pct}%`}</b></div></div>
      <p>${escapeHtml(discount.explanation)}</p></section>
    ${weakDiscount}
    <section class="similar-section"><div class="similar-heading"><h3>Similar products</h3><span>CATEGORY · PRICE · RATING</span></div><div class="similar-grid">${similar}</div></section>
    <p class="model-disclaimer">${escapeHtml(result.model_note)}</p>`;
}

async function analyzeProduct(productId, navigate = true) {
  state.selectedId = productId || null;
  byId("analysis-area").innerHTML = `<div class="loading-state">Comparing product and market signals…</div>`;
  byId("search-results").hidden = true;
  try {
    const result = await requestJson("/api/analyze", { method: "POST", body: JSON.stringify({ product_id: productId }) });
    state.result = result;
    state.selectedId = result.product.id;
    byId("analysis-area").innerHTML = resultMarkup(result);
    byId("breadcrumb-current").textContent = result.product.name.toUpperCase().slice(0, 26);
    if (navigate) showView("analyze");
    drawPriceChart(result.history, result.recent_median);
  } catch (error) {
    byId("analysis-area").innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`;
    showToast(error.message);
  }
}

async function analyzeManual(form) {
  const values = Object.fromEntries(new FormData(form).entries());
  values.current_price = Number(values.current_price);
  values.list_price = Number(values.list_price || values.current_price);
  values.rating = Number(values.rating || 4.2);
  try {
    const result = await requestJson("/api/analyze", { method: "POST", body: JSON.stringify(values) });
    state.result = result;
    state.selectedId = null;
    byId("analysis-area").innerHTML = resultMarkup(result);
    byId("breadcrumb-current").textContent = "CUSTOM PRODUCT";
    drawPriceChart(result.history, result.recent_median);
  } catch (error) {
    showToast(error.message);
  }
}

function drawPriceChart(prices, medianPrice) {
  const canvas = byId("price-chart");
  if (!canvas) return;
  const bounds = canvas.getBoundingClientRect();
  if (!bounds.width || !bounds.height) return;
  const ratio = window.devicePixelRatio || 1;
  canvas.width = Math.round(bounds.width * ratio);
  canvas.height = Math.round(bounds.height * ratio);
  const context = canvas.getContext("2d");
  context.scale(ratio, ratio);
  const width = bounds.width;
  const height = bounds.height;
  const padding = { top: 12, right: 12, bottom: 20, left: 48 };
  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;
  context.clearRect(0, 0, width, height);
  if (!prices.length) {
    context.fillStyle = "#879087";
    context.font = "11px 'Manrope', sans-serif";
    context.textAlign = "center";
    context.textBaseline = "middle";
    context.fillText("No historical prices supplied", width / 2, height / 2);
    return;
  }
  const min = Math.min(...prices, medianPrice) * 0.94;
  const max = Math.max(...prices, medianPrice) * 1.04;
  const x = (index) => padding.left + (index / Math.max(prices.length - 1, 1)) * chartWidth;
  const y = (value) => padding.top + (1 - (value - min) / Math.max(max - min, 1)) * chartHeight;

  context.font = "9px 'DM Mono', monospace";
  context.textBaseline = "middle";
  for (let line = 0; line < 3; line += 1) {
    const py = padding.top + (line / 2) * chartHeight;
    context.strokeStyle = "#edf0eb";
    context.lineWidth = 1;
    context.beginPath(); context.moveTo(padding.left, py); context.lineTo(width - padding.right, py); context.stroke();
    const value = max - (line / 2) * (max - min);
    context.fillStyle = "#879087";
    context.textAlign = "left";
    context.fillText(`${Math.round(value / 1000)}k`, 1, py);
  }

  context.setLineDash([4, 4]);
  context.strokeStyle = "#c5a44e";
  context.beginPath(); context.moveTo(padding.left, y(medianPrice)); context.lineTo(width - padding.right, y(medianPrice)); context.stroke();
  context.setLineDash([]);
  context.strokeStyle = "#617b3a";
  context.lineWidth = 2.5;
  context.lineJoin = "round";
  context.beginPath();
  prices.forEach((price, index) => index ? context.lineTo(x(index), y(price)) : context.moveTo(x(index), y(price)));
  context.stroke();
  context.fillStyle = "#617b3a";
  prices.forEach((price, index) => { context.beginPath(); context.arc(x(index), y(price), index === prices.length - 1 ? 3.5 : 2, 0, Math.PI * 2); context.fill(); });
  context.fillStyle = "#8c948b";
  context.textAlign = "left"; context.fillText("90 days ago", padding.left, height - 8);
  context.textAlign = "right"; context.fillText("Today", width - padding.right, height - 8);
}

async function updateWatchlist(productId, shouldSave) {
  try {
    await requestJson(`/api/watchlist/${encodeURIComponent(productId)}`, { method: shouldSave ? "POST" : "DELETE" });
    await refreshWatchlistCount();
    if (state.result && state.result.product.id === productId) {
      state.result.product.saved = shouldSave;
      byId("analysis-area").innerHTML = resultMarkup(state.result);
      drawPriceChart(state.result.history, state.result.recent_median);
    }
    showToast(shouldSave ? "Added to your local watchlist." : "Removed from your watchlist.");
    if (!byId("watchlist-view").hidden) loadWatchlist();
    if (!byId("dashboard-view").hidden) loadDashboard();
  } catch (error) { showToast(error.message); }
}

async function refreshWatchlistCount() {
  try {
    const saved = await requestJson("/api/watchlist");
    byId("watchlist-count").textContent = saved.length;
  } catch { byId("watchlist-count").textContent = "0"; }
}

async function loadWatchlist() {
  const grid = byId("watchlist-grid");
  grid.innerHTML = `<div class="loading-state">Loading saved products…</div>`;
  try {
    const saved = await requestJson("/api/watchlist");
    byId("watchlist-count").textContent = saved.length;
    if (!saved.length) {
      grid.innerHTML = emptyStateMarkup("bag", "Your watchlist is clear", "Save a product from its analysis to keep its price and deal score close.", "watchlist-empty");
      return;
    }
    grid.innerHTML = saved.map((item) => `
      <article class="watch-item">${imageTag(item.product.image, item.product.name)}<button class="watch-open" type="button" data-product-id="${escapeHtml(item.product.id)}"><span class="small-label">${escapeHtml(item.product.brand)} · ${escapeHtml(item.product.category)}</span><b>${escapeHtml(item.product.name)}</b><small>${escapeHtml(item.status)} · ${item.deal_score}/100</small></button>
      <div class="watch-item-price"><b>${money(item.current_price)}</b><span>Fair ${money(item.estimated_fair_price)}</span><span class="${item.price_movement.change_pct < 0 ? "movement-down" : "movement-up"}">${item.price_movement.change_pct < 0 ? "↓" : item.price_movement.change_pct > 0 ? "↑" : "→"} ${Math.abs(item.price_movement.change_pct)}% price movement</span></div><button class="watch-remove" type="button" data-remove-id="${escapeHtml(item.product.id)}" aria-label="Remove ${escapeHtml(item.product.name)}">×</button></article>`).join("");
  } catch (error) { grid.innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`; }
}

function renderActivity(items, targetId) {
  const target = byId(targetId);
  const seenProducts = new Set();
  items = items.filter((item) => {
    if (seenProducts.has(item.id)) return false;
    seenProducts.add(item.id);
    return true;
  });
  if (!items.length) {
    target.innerHTML = emptyStateMarkup("search", "No product checks yet", "Analyze a listing to start your activity.", "compact-empty");
    return;
  }
  target.innerHTML = items.map((item) => `
    <button class="activity-row" type="button" data-product-id="${escapeHtml(item.id)}">${imageTag(item.image, item.name)}<span class="activity-copy"><b>${escapeHtml(item.name)}</b><small>${escapeHtml(item.brand)} · ${new Date(item.created_at).toLocaleDateString()}</small></span><span class="activity-result"><strong>${money(item.current_price)}</strong><small>${escapeHtml(item.status)} · ${item.deal_score}/100</small></span></button>`).join("");
}

async function loadDashboard() {
  const requestId = ++state.dashboardRequest;
  try {
    const dashboard = await requestJson("/api/dashboard");
    if (requestId !== state.dashboardRequest) return;
    state.dashboard = dashboard;
    const { summary } = state.dashboard;
    byId("dashboard-metrics").innerHTML = [
      ["PRODUCTS TRACKED", summary.products_tracked, "Saved to your watchlist"],
      ["GOOD DEALS FOUND", summary.good_deals_found, "Strong Deal signals in catalog"],
      ["POTENTIAL SAVINGS", money(summary.potential_savings), "Across saved products"],
      ["PRICE DROPS", summary.price_drops, "Since previous stored price"],
    ].map(([label, value, note]) => `<article class="dashboard-metric"><small>${label}</small><strong>${value}</strong><span>${note}</span></article>`).join("");

    const distribution = state.dashboard.score_distribution;
    const total = Math.max(1, Object.values(distribution).reduce((sum, value) => sum + value, 0));
    byId("score-distribution").innerHTML = Object.entries(distribution).map(([label, count]) => `
      <div class="distribution-row"><span>${escapeHtml(label)}</span><div class="distribution-track"><i class="distribution-fill ${label === "Strong Deal" ? "is-strong" : ""}" style="--distribution:${count / total * 100}%"></i></div><b>${count}</b></div>`).join("");

    const movement = state.dashboard.price_movement;
    byId("dashboard-movement").innerHTML = movement.length ? movement.map((item) => `
      <button class="movement-row" type="button" data-product-id="${escapeHtml(item.product_id)}"><span><b>${escapeHtml(item.name)}</b><small>${money(item.previous_price)} → ${money(item.current_price)}</small></span><strong class="${item.change_pct < 0 ? "movement-down" : "movement-up"}">${item.change_pct < 0 ? "↓" : item.change_pct > 0 ? "↑" : "→"} ${Math.abs(item.change_pct)}%</strong></button>`).join("") : emptyStateMarkup("tag", "No tracked price movement", "Save a product to see changes against its previous stored price.", "compact-empty");

    renderActivity(state.dashboard.recent_activity, "dashboard-activity");
    renderActivity(state.dashboard.recent_activity.slice(0, 3), "recently-analyzed");
    byId("dashboard-note").textContent = state.dashboard.data_note;
  } catch (error) {
    if (requestId !== state.dashboardRequest) return;
    byId("dashboard-metrics").innerHTML = `<div class="empty-state">Dashboard data is unavailable. ${escapeHtml(error.message)}</div>`;
  }
}

function populateComparisonOptions() {
  const options = state.products.map((product) => `<option value="${escapeHtml(product.id)}">${escapeHtml(product.name)}</option>`).join("");
  byId("compare-a").innerHTML = options;
  byId("compare-b").innerHTML = options;
  if (state.products.length > 1) byId("compare-b").selectedIndex = 1;
}

async function compareSelectedProducts(event) {
  event.preventDefault();
  const resultTarget = byId("comparison-result");
  resultTarget.innerHTML = `<div class="loading-state">Comparing stored product data…</div>`;
  try {
    const results = await requestJson("/api/compare", {
      method: "POST",
      body: JSON.stringify({ product_ids: [byId("compare-a").value, byId("compare-b").value] }),
    });
    const rows = [
      ["Current price", (item) => money(item.current_price)],
      ["Estimated fair price", (item) => money(item.estimated_fair_price)],
      ["Difference from fair", (item) => `${Math.abs(item.difference_pct)}% ${item.difference_pct >= 0 ? "below" : "above"}`],
      ["Deal score", (item) => `${item.deal_score} / 100`],
      ["Deal category", (item) => item.status],
      ["Rating", (item) => `${Number(item.product.rating).toFixed(1)} / 5`],
      ["Historical low", (item) => item.historical_low === null ? "—" : money(item.historical_low)],
      ["Historical average", (item) => item.historical_average === null ? "—" : money(item.historical_average)],
    ];
    resultTarget.innerHTML = `<div class="comparison-table"><div class="comparison-row comparison-header"><span>PRICE SIGNAL</span>${results.map((item) => `<strong>${escapeHtml(item.product.name)}</strong>`).join("")}</div>${rows.map(([label, value]) => `<div class="comparison-row"><span>${label}</span>${results.map((item) => `<strong>${escapeHtml(value(item))}</strong>`).join("")}</div>`).join("")}</div>`;
  } catch (error) {
    resultTarget.innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`;
  }
}

function showView(viewName) {
  const views = ["discover", "analyze", "watchlist", "dashboard"];
  if (!views.includes(viewName)) viewName = "discover";
  views.forEach((view) => { byId(`${view}-view`).hidden = view !== viewName; });
  document.querySelectorAll(".nav-link").forEach((link) => link.classList.toggle("is-active", link.dataset.view === viewName));
  byId("breadcrumb-current").textContent = viewName.toUpperCase();
  if (viewName === "watchlist") loadWatchlist();
  if (viewName === "dashboard") loadDashboard();
  if (viewName === "analyze" && state.result) drawPriceChart(state.result.history, state.result.recent_median);
}

function renderSearchResults(term) {
  const container = byId("search-results");
  const normalized = term.trim().toLowerCase();
  if (!normalized) { container.hidden = true; return; }
  const matches = state.products.filter((product) => `${product.name} ${product.brand} ${product.category}`.toLowerCase().includes(normalized)).slice(0, 5);
  container.innerHTML = matches.length ? matches.map((product) => `
    <button class="search-result" type="button" role="option" data-product-id="${escapeHtml(product.id)}">${imageTag(product.image, "")}<span><b>${escapeHtml(product.name)}</b><small>${escapeHtml(product.brand)} · ${escapeHtml(product.category)}</small></span><strong>${money(product.current_price)}</strong></button>`).join("") : `<div class="search-result search-result-empty">${illustrationMarkup("search", "search-empty")}<span><b>No product match</b><small>Try another name, brand or category.</small></span></div>`;
  container.hidden = false;
}

document.addEventListener("click", (event) => {
  const viewButton = event.target.closest("[data-view]");
  if (viewButton) { showView(viewButton.dataset.view); return; }
  const productButton = event.target.closest("[data-product-id]");
  if (productButton) { analyzeProduct(productButton.dataset.productId); window.scrollTo({ top: 0, behavior: "smooth" }); return; }
  const removeButton = event.target.closest("[data-remove-id]");
  if (removeButton) updateWatchlist(removeButton.dataset.removeId, false);
  if (!event.target.closest(".search-panel")) byId("search-results").hidden = true;
});

byId("search-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const term = byId("product-search").value.trim().toLowerCase();
  if (!term) { showToast("Search for a product, brand or category first."); return; }
  let matches;
  try { matches = await requestJson(`/api/products?q=${encodeURIComponent(term)}`); }
  catch (error) { showToast(`Product search is unavailable. ${error.message}`); return; }
  const match = matches[0];
  if (match) analyzeProduct(match.id);
  else {
    byId("manual-form").hidden = false;
    byId("manual-form").elements.namedItem("name").value = byId("product-search").value.trim();
    byId("manual-form").elements.namedItem("name").focus();
    if (!term) showToast("Choose a sample product or enter its details manually.");
  }
});
byId("product-search").addEventListener("input", (event) => renderSearchResults(event.target.value));
byId("manual-toggle").addEventListener("click", () => { byId("manual-form").hidden = !byId("manual-form").hidden; });
byId("manual-form").addEventListener("submit", (event) => { event.preventDefault(); analyzeManual(event.currentTarget); });
byId("compare-form").addEventListener("submit", compareSelectedProducts);
byId("analysis-area").addEventListener("click", (event) => {
  if (event.target.closest("#save-product") && state.result?.product.id !== "custom") {
    const button = byId("save-product");
    updateWatchlist(state.result.product.id, !button.classList.contains("is-saved"));
  }
});
window.addEventListener("resize", () => { if (state.result) drawPriceChart(state.result.history, state.result.recent_median); });

byId("today-date").textContent = new Intl.DateTimeFormat("en", { month: "short", day: "2-digit", year: "numeric" }).format(new Date()).toUpperCase();
requestJson("/api/products").then((products) => {
  state.products = products;
  renderCatalog();
  populateComparisonOptions();
  refreshWatchlistCount();
  loadDashboard();
  analyzeProduct(products[0]?.id, false);
}).catch((error) => {
  byId("popular-product-grid").innerHTML = `<div class="empty-state">The local DealSense service is unavailable. Refresh after the backend starts. ${escapeHtml(error.message)}</div>`;
  byId("good-deal-grid").innerHTML = `<div class="empty-state">Product data is unavailable.</div>`;
  byId("dashboard-metrics").innerHTML = `<div class="empty-state">Dashboard data is unavailable.</div>`;
});
