from pathlib import Path

from ml.price_model import train_and_save


if __name__ == "__main__":
    metrics = train_and_save(Path(__file__).resolve().parents[1])
    print("Model trained and saved.")
    for name, value in metrics.items():
        print(f"{name}: {value}")