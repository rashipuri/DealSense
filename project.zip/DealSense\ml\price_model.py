from __future__ import annotations

import json
import math
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


CATEGORICAL_FEATURES = ["category", "brand"]
NUMERIC_FEATURES = ["rating", "reviews", "spec_level", "list_price"]
FEATURES = CATEGORICAL_FEATURES + NUMERIC_FEATURES
TARGET = "typical_price"
MODEL_SCHEMA_VERSION = 2


def _training_frame() -> pd.DataFrame:
    random = np.random.default_rng(20260930)
    categories = {
        "Audio": 6500,
        "Footwear": 7600,
        "Wearables": 12800,
        "Phones": 41000,
        "Cameras": 52000,
        "Home": 8200,
        "Laptops": 61000,
        "Fitness": 9000,
    }
    brands = {
        "Auraloop": 1.03,
        "Soundcore": 0.96,
        "Nimbus": 0.94,
        "Stride": 1.08,
        "Northstar": 1.12,
        "Pixel": 1.12,
        "Fujifilm": 1.22,
        "BrewHaus": 1.08,
        "Lenovo": 0.98,
        "Garmin": 1.26,
        "Other": 1.0,
    }
    rows = []
    brand_names = list(brands)
    category_names = list(categories)
    for index in range(1100):
        category = category_names[index % len(category_names)]
        brand = brand_names[(index * 7 + index // len(category_names)) % len(brand_names)]
        rating = round(float(random.uniform(3.2, 4.9)), 2)
        reviews = int(random.integers(25, 18000))
        spec_level = round(float(random.uniform(0.08, 0.98)), 3)
        base = categories[category] * brands[brand]
        specification_factor = 0.74 + spec_level * 0.45
        rating_factor = 0.92 + (rating - 3.5) * 0.055
        review_factor = 1 + math.log10(reviews + 1) * 0.012
        typical_price = base * specification_factor * rating_factor * review_factor
        typical_price *= float(random.normal(1, 0.045))
        list_price = typical_price * float(random.uniform(1.08, 1.55))
        rows.append({
            "category": category,
            "brand": brand,
            "rating": rating,
            "reviews": reviews,
            "spec_level": spec_level,
            "list_price": round(list_price, 2),
            "typical_price": round(max(250, typical_price), 2),
        })
    return pd.DataFrame(rows)


def build_pipeline() -> Pipeline:
    preprocessing = ColumnTransformer(
        transformers=[
            ("category_brand", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL_FEATURES),
            ("numeric", StandardScaler(), NUMERIC_FEATURES),
        ]
    )
    return Pipeline([
        ("features", preprocessing),
        ("regressor", RandomForestRegressor(
            n_estimators=220,
            min_samples_leaf=2,
            max_features=0.9,
            random_state=42,
            n_jobs=-1,
        )),
    ])


def train_and_save(root: Path) -> dict:
    data_dir = root / "data"
    artifacts_dir = root / "artifacts"
    reports_dir = root / "reports"
    artifacts_dir.mkdir(exist_ok=True)
    reports_dir.mkdir(exist_ok=True)

    frame = _training_frame()
    rows_before_cleaning = len(frame)
    frame = frame.drop_duplicates(subset=FEATURES).dropna(subset=FEATURES + [TARGET])
    frame = frame[
        frame[TARGET].gt(0)
        & frame["rating"].between(1, 5)
        & frame["reviews"].ge(0)
        & frame["spec_level"].between(0, 1)
    ]
    frame.to_csv(data_dir / "synthetic_training_data.csv", index=False)
    train, test = train_test_split(frame, test_size=0.2, random_state=42)
    pipeline = build_pipeline()
    pipeline.fit(train[FEATURES], train[TARGET])
    predictions = pipeline.predict(test[FEATURES])
    baseline = DummyRegressor(strategy="mean")
    baseline.fit(train[FEATURES], train[TARGET])
    baseline_predictions = baseline.predict(test[FEATURES])
    forest_mae = float(mean_absolute_error(test[TARGET], predictions))
    baseline_mae = float(mean_absolute_error(test[TARGET], baseline_predictions))
    comparison = [
        {
            "name": "Mean baseline",
            "mae": round(baseline_mae, 2),
            "rmse": round(float(np.sqrt(mean_squared_error(test[TARGET], baseline_predictions))), 2),
            "r2": round(float(r2_score(test[TARGET], baseline_predictions)), 4),
        },
        {
            "name": "Random Forest",
            "mae": round(forest_mae, 2),
            "rmse": round(float(np.sqrt(mean_squared_error(test[TARGET], predictions))), 2),
            "r2": round(float(r2_score(test[TARGET], predictions)), 4),
        },
    ]
    selected_model = "Random Forest" if forest_mae <= baseline_mae else "Mean baseline"
    selected_predictions = predictions if selected_model == "Random Forest" else baseline_predictions
    metrics = {
        "model": selected_model,
        "rows": int(len(frame)),
        "rows_before_cleaning": int(rows_before_cleaning),
        "train_rows": int(len(train)),
        "test_rows": int(len(test)),
        "sklearn_version": sklearn.__version__,
        "model_schema_version": MODEL_SCHEMA_VERSION,
        "mae": round(float(mean_absolute_error(test[TARGET], selected_predictions)), 2),
        "rmse": round(float(np.sqrt(mean_squared_error(test[TARGET], selected_predictions))), 2),
        "r2": round(float(r2_score(test[TARGET], selected_predictions)), 4),
        "model_comparison": comparison,
        "data_note": "Synthetic demonstration data generated with a fixed seed; not retailer-collected observations.",
    }
    selected_estimator = pipeline if selected_model == "Random Forest" else baseline
    selected_estimator.fit(frame[FEATURES], frame[TARGET])
    joblib.dump(selected_estimator, artifacts_dir / "price_model.joblib")
    (reports_dir / "model_metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    return metrics


class PriceEstimator:
    def __init__(self, root: Path):
        self.root = root
        self.model_path = root / "artifacts" / "price_model.joblib"
        metrics_path = root / "reports" / "model_metrics.json"
        self.metrics = json.loads(metrics_path.read_text(encoding="utf-8")) if metrics_path.exists() else {}
        if (
            not self.model_path.exists()
            or self.metrics.get("sklearn_version") != sklearn.__version__
            or self.metrics.get("model_schema_version") != MODEL_SCHEMA_VERSION
        ):
            train_and_save(root)
            self.metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
        self.model = joblib.load(self.model_path)

    def predict(self, product: dict) -> float:
        row = pd.DataFrame([{
            "category": str(product.get("category", "Other")),
            "brand": str(product.get("brand", "Other")),
            "rating": float(product.get("rating", 4.0)),
            "reviews": int(product.get("reviews", 100)),
            "spec_level": max(0, min(1, float(product.get("spec_level", 0.5)))),
            "list_price": max(0, float(product.get("list_price", product.get("current_price", 0) * 1.25))),
        }], columns=FEATURES)
        return float(self.model.predict(row)[0])

    def metadata(self) -> dict:
        return {
            "name": f"{self.metrics.get('model', 'Random Forest')} price estimator",
            "metrics": self.metrics,
        }