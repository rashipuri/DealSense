from __future__ import annotations

import math
from pathlib import Path
from statistics import fmean, median

from flask import Flask, jsonify, request, url_for

import database
from ml.price_model import PriceEstimator
from pricing import build_explanations, calculate_deal_score, classify_deal


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
WATCHLIST_PATH = DATA_DIR / "watchlist.json"
CATALOG_PATH = DATA_DIR / "products.json"
DATABASE_PATH = DATA_DIR / "dealsense.sqlite3"

app = Flask(__name__, static_folder="static", static_url_path="/static")
database.initialize_database(DATABASE_PATH, CATALOG_PATH, WATCHLIST_PATH)
estimator = PriceEstimator(ROOT)


def _money(value: float) -> float:
    return round(max(0, float(value)), 2)


def _analyze(product: dict) -> dict:
    current_price = float(product["current_price"])
    listed_price = float(product.get("list_price") or current_price)
    fair_price = estimator.predict(product)
    history = [float(value) for value in product.get("history", [])]
    historical_average = product.get("historical_average")
    recent_average = product.get("recent_average")
    has_history = bool(history)
    recent_prices = history[-5:]
    recent_median = median(recent_prices) if recent_prices else None
    historical_low = product.get("historical_low")
    historical_high = product.get("historical_high")
    deviation = (fair_price - current_price) / fair_price if fair_price else 0
    actual_saving = (recent_average - current_price) / recent_average if recent_average else None
    displayed_discount = (listed_price - current_price) / listed_price if listed_price else 0
    weak_discount = has_history and displayed_discount - actual_saving >= 0.15 and displayed_discount >= 0.2
    status, deviation = classify_deal(current_price, fair_price)
    score, score_explanation = calculate_deal_score(current_price, fair_price, float(product["rating"]), history)
    explanations = build_explanations(current_price, fair_price, float(product["rating"]), history)
    similar = [
        _product_summary(item)
        for item in database.find_similar_products(DATABASE_PATH, product["id"], limit=3)
    ] if product["id"] != "custom" else []
    history_points = product.get("history_points", [])
    previous_price = history_points[-2]["price"] if len(history_points) > 1 else None
    movement_pct = (current_price - previous_price) / previous_price * 100 if previous_price else None
    history_prices = [float(point["price"]) for point in history_points]

    return {
        "product": product,
        "current_price": _money(current_price),
        "typical_price": _money(fair_price),
        "estimated_fair_price": _money(fair_price),
        "price_difference": round(current_price - fair_price, 2),
        "recent_median": _money(recent_median) if recent_median is not None else None,
        "recent_average_price": _money(recent_average) if recent_average is not None else None,
        "historical_average": _money(historical_average) if historical_average is not None else None,
        "historical_low": _money(historical_low) if historical_low is not None else None,
        "historical_high": _money(historical_high) if historical_high is not None else None,
        "displayed_discount_pct": round(displayed_discount * 100, 1),
        "actual_recent_saving_pct": round(actual_saving * 100, 1) if actual_saving is not None else None,
        "difference_pct": round(deviation * 100, 1),
        "deal_score": score,
        "status": status,
        "weak_discount": weak_discount,
        "history": history_prices,
        "history_points": history_points,
        "has_history": has_history,
        "explanations": explanations,
        "score_explanation": score_explanation,
        "comparables": similar,
        "discount_reality": {
            "original_price": _money(listed_price),
            "displayed_discount_pct": round(displayed_discount * 100, 1),
            "current_price": _money(current_price),
            "recent_average_price": _money(recent_average) if recent_average is not None else None,
            "historical_low": _money(historical_low) if historical_low is not None else None,
            "actual_saving_pct": round(actual_saving * 100, 1) if actual_saving is not None else None,
            "explanation": "The displayed discount is based on MRP. Compared with recent selling prices, the effective saving is smaller." if weak_discount else "Compare the listed discount with the stored recent average; MRP alone does not describe price history.",
        },
        "price_movement_pct": round(movement_pct, 1) if movement_pct is not None else None,
        "model_note": f"DealSense provides an estimated price from the {estimator.metadata()['name']} and stored demo price history. Predictions are informational and are not guaranteed.",
    }


def _product_summary(product: dict) -> dict:
    fair_price = estimator.predict(product)
    status, difference = classify_deal(float(product["current_price"]), fair_price)
    score, _ = calculate_deal_score(float(product["current_price"]), fair_price, float(product["rating"]), product.get("history", []))
    return {
        "id": product["id"],
        "name": product["name"],
        "brand": product["brand"],
        "category": product["category"],
        "current_price": _money(product["current_price"]),
        "price": _money(product["current_price"]),
        "estimated_fair_price": _money(fair_price),
        "rating": product["rating"],
        "deal_score": score,
        "status": status,
        "difference_pct": round(difference * 100, 1),
        "historical_low": product.get("historical_low"),
        "historical_average": _money(product["historical_average"]) if product.get("historical_average") is not None else None,
        "history": product.get("history", []),
        "image": product["image"],
        "url": url_for("product_detail", product_id=product["id"]),
    }


@app.get("/")
def home():
    return app.send_static_file("index.html")


@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "model": estimator.metadata()})


@app.get("/api/products")
def products():
    query = request.args.get("q", "").strip().casefold()
    items = database.list_products(DATABASE_PATH)
    if query:
        items = [item for item in items if query in f"{item['name']} {item['brand']} {item['category']}".casefold()]
    saved_ids = database.watchlist_ids(DATABASE_PATH)
    return jsonify([{**item, **_product_summary(item), "saved": item["id"] in saved_ids} for item in items])


@app.get("/api/products/<product_id>")
def product_detail(product_id: str):
    product = database.get_product(DATABASE_PATH, product_id)
    if not product:
        return jsonify({"error": "Product not found."}), 404
    return jsonify(_analyze(product))


@app.get("/api/products/<product_id>/history")
def product_history(product_id: str):
    product = database.get_product(DATABASE_PATH, product_id)
    if not product:
        return jsonify({"error": "Product not found."}), 404
    points = database.get_price_history(DATABASE_PATH, product_id)
    prices = [point["price"] for point in points]
    return jsonify({
        "product_id": product_id,
        "history": points,
        "current_price": product["current_price"],
        "historical_low": min(prices) if prices else None,
        "historical_high": max(prices) if prices else None,
        "historical_average": round(fmean(prices), 2) if prices else None,
        "recent_average": product["recent_average"],
        "source": "bundled synthetic demonstration observations" if points else "no stored history",
    })


@app.get("/api/products/<product_id>/similar")
def similar_products(product_id: str):
    if not database.get_product(DATABASE_PATH, product_id):
        return jsonify({"error": "Product not found."}), 404
    return jsonify([_product_summary(item) for item in database.find_similar_products(DATABASE_PATH, product_id)])


@app.post("/api/analyze")
def analyze():
    payload = request.get_json(silent=True) or {}
    try:
        product_id = payload.get("product_id")
        product = database.get_product(DATABASE_PATH, str(product_id)) if product_id else None
        if product_id and product is None:
            return jsonify({"error": "Product not found."}), 404
        if product is None:
            product = {
                "id": "custom",
                "name": str(payload.get("name", "Custom product"))[:100],
                "brand": str(payload.get("brand", "Other"))[:60],
                "category": str(payload.get("category", "Audio"))[:60],
                "seller": str(payload.get("seller", "Your listing"))[:80],
                "rating": float(payload.get("rating", 4.2)),
                "reviews": int(payload.get("reviews", 250)),
                "spec_level": float(payload.get("spec_level", 0.55)),
                "current_price": float(payload.get("current_price", 0)),
                "list_price": float(payload.get("list_price") or payload.get("current_price", 0)),
                "image": payload.get("image", ""),
                "description": "User-entered listing",
                "history": payload.get("history") or [],
                "history_points": [],
                "historical_low": None,
                "historical_high": None,
                "historical_average": None,
                "recent_average": None,
            }
        if not math.isfinite(float(product["current_price"])) or float(product["current_price"]) <= 0:
            raise ValueError("Enter a current price greater than zero.")
        if not math.isfinite(float(product["list_price"])) or float(product["list_price"]) <= 0:
            raise ValueError("Original price must be greater than zero.")
        if not math.isfinite(float(product["rating"])) or not 1 <= float(product["rating"]) <= 5:
            raise ValueError("Rating must be between 1 and 5.")
        result = _analyze(product)
        if product["id"] != "custom":
            database.record_activity(DATABASE_PATH, product["id"], "analyzed")
    except (TypeError, ValueError, OverflowError) as error:
        return jsonify({"error": str(error)}), 400
    return jsonify(result)


@app.get("/api/watchlist")
def get_watchlist():
    saved_products = database.list_watchlist(DATABASE_PATH)
    results = []
    for product in saved_products:
        result = _analyze(product)
        points = product.get("history_points", [])
        prior = points[-2]["price"] if len(points) > 1 else product["current_price"]
        result["product"]["saved"] = True
        result["price_movement"] = {
            "previous_price": prior,
            "current_price": product["current_price"],
            "difference": round(product["current_price"] - prior, 2),
            "change_pct": round((product["current_price"] - prior) / prior * 100, 1) if prior else 0,
        }
        results.append(result)
    return jsonify(results)


@app.post("/api/watchlist/<product_id>")
@app.post("/api/watchlist")
def add_to_watchlist(product_id: str | None = None):
    payload = request.get_json(silent=True) or {}
    product_id = product_id or payload.get("product_id")
    if not product_id:
        return jsonify({"error": "Provide a product_id to save."}), 400
    if not database.save_to_watchlist(DATABASE_PATH, str(product_id)):
        return jsonify({"error": "Product not found."}), 404
    return jsonify({"saved": True, "count": len(database.list_watchlist(DATABASE_PATH))})


@app.delete("/api/watchlist/<product_id>")
def remove_from_watchlist(product_id: str):
    database.remove_from_watchlist(DATABASE_PATH, product_id)
    return jsonify({"saved": False, "count": len(database.list_watchlist(DATABASE_PATH))})


@app.get("/api/dashboard")
def dashboard():
    catalog = database.list_products(DATABASE_PATH)
    analyzed_catalog = [_analyze(product) for product in catalog]
    saved_products = database.list_watchlist(DATABASE_PATH)
    saved_results = [_analyze(product) for product in saved_products]
    score_distribution = {label: 0 for label in ("Strong Deal", "Fair Price", "Slightly Expensive", "Overpriced")}
    for result in analyzed_catalog:
        score_distribution[result["status"]] += 1

    price_movement = []
    price_drops = 0
    for product, result in zip(saved_products, saved_results):
        points = product.get("history_points", [])
        previous = points[-2]["price"] if len(points) > 1 else product["current_price"]
        change = round((product["current_price"] - previous) / previous * 100, 1) if previous else 0
        if change < 0:
            price_drops += 1
        price_movement.append({
            "product_id": product["id"],
            "name": product["name"],
            "current_price": product["current_price"],
            "previous_price": previous,
            "change_pct": change,
            "history": product.get("history", []),
        })

    activity = database.recent_activity(DATABASE_PATH)
    recent_results = []
    for entry in activity:
        product = database.get_product(DATABASE_PATH, entry["id"]) if entry.get("id") else None
        if product:
            result = _product_summary(product)
            result.update({"action": entry["action"], "created_at": entry["created_at"]})
            recent_results.append(result)

    return jsonify({
        "summary": {
            "products_tracked": len(saved_products),
            "good_deals_found": sum(result["status"] == "Strong Deal" for result in analyzed_catalog),
            "potential_savings": round(sum(max(0, result["estimated_fair_price"] - result["current_price"]) for result in saved_results), 2),
            "price_drops": price_drops,
        },
        "saved_products": saved_results,
        "score_distribution": score_distribution,
        "price_movement": price_movement,
        "recent_activity": recent_results,
        "catalog_size": len(catalog),
        "data_note": "Metrics use the bundled synthetic catalog and locally stored watchlist/history.",
    })


@app.post("/api/compare")
def compare_products():
    payload = request.get_json(silent=True) or {}
    product_ids = payload.get("product_ids", [])
    if not isinstance(product_ids, list) or len(product_ids) != 2:
        return jsonify({"error": "Choose exactly two products to compare."}), 400
    if product_ids[0] == product_ids[1]:
        return jsonify({"error": "Choose two different products to compare."}), 400
    products_to_compare = [database.get_product(DATABASE_PATH, str(product_id)) for product_id in product_ids]
    if any(product is None for product in products_to_compare):
        return jsonify({"error": "One or more products were not found."}), 404
    return jsonify([_analyze(product) for product in products_to_compare])


@app.errorhandler(404)
def not_found(error):
    if request.path.startswith("/api/"):
        return jsonify({"error": "The requested API resource was not found."}), 404
    return error


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8000, debug=False)