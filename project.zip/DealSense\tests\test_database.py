import json
import tempfile
import unittest
from pathlib import Path

from database import (
    find_similar_products,
    get_price_history,
    get_product,
    initialize_database,
    list_products,
    list_watchlist,
    recent_activity,
    record_activity,
    remove_from_watchlist,
    save_to_watchlist,
)


class DealSenseDatabaseTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.root = Path(self.temp_dir.name)
        self.database_path = self.root / "dealsense.sqlite3"
        self.catalog_path = self.root / "products.json"
        self.catalog_path.write_text(json.dumps([
            {
                "id": "item-a", "name": "Item A", "brand": "Brand", "category": "Audio",
                "seller": "Shop", "rating": 4.6, "reviews": 120, "spec_level": 0.6,
                "current_price": 100, "list_price": 150, "image": "", "description": "Test",
                "history": [130, 120, 100],
            },
            {
                "id": "item-b", "name": "Item B", "brand": "Brand", "category": "Audio",
                "seller": "Shop", "rating": 4.5, "reviews": 90, "spec_level": 0.5,
                "current_price": 110, "list_price": 160, "image": "", "description": "Test",
                "history": [125, 120, 110],
            },
        ]), encoding="utf-8")
        initialize_database(self.database_path, self.catalog_path)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_seed_migrates_products_and_history_once(self):
        initialize_database(self.database_path, self.catalog_path)
        products = list_products(self.database_path)
        self.assertEqual(len(products), 2)
        self.assertEqual(products[0]["historical_low"], 100)
        self.assertEqual(len(get_price_history(self.database_path, "item-a")), 3)

    def test_similar_products_use_category_price_and_rating(self):
        similar = find_similar_products(self.database_path, "item-a")
        self.assertEqual([product["id"] for product in similar], ["item-b"])

    def test_watchlist_and_activity_persist(self):
        self.assertTrue(save_to_watchlist(self.database_path, "item-a"))
        self.assertEqual(len(list_watchlist(self.database_path)), 1)
        record_activity(self.database_path, "item-a", "analyzed")
        self.assertEqual(recent_activity(self.database_path)[0]["name"], "Item A")
        remove_from_watchlist(self.database_path, "item-a")
        self.assertEqual(list_watchlist(self.database_path), [])

    def test_missing_product_is_not_fabricated(self):
        self.assertIsNone(get_product(self.database_path, "missing"))
        self.assertFalse(save_to_watchlist(self.database_path, "missing"))


if __name__ == "__main__":
    unittest.main()