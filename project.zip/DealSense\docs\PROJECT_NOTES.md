# Project notes

## Problem and audience

Online storefronts can emphasize a large discount from a listed price even when the current offer is close to the price buyers have recently seen. DealSense is for shoppers who want a quick context check before comparing listings or deciding whether to wait.

## Product principle

Answer “Is this product actually a good deal?” with evidence rather than a black-box verdict. A user should be able to see current versus estimated typical pricing, recent price movement, comparable sample products and the factors behind the label.

## Primary flow

1. Find a product in the sample shelf or enter its details.
2. Analyze the listing and review the estimate, status and score.
3. Check the 90-day demo history and plain-language comparison factors.
4. Compare similar sample products or save a product to the local watchlist.

## Scope in this implementation

- Product search and manual price input.
- Regression estimate of fair price from product attributes and MRP, compared with a mean-price baseline.
- Four deal labels and a transparent, formula-based 0–100 score.
- 12 weekly sample price observations, median, high/low and chart.
- A weak-discount comparison that distinguishes listed discount from recent-price savings.
- Comparable demo listings and persistent, local watchlist.
- Model health endpoint and reproducible training/evaluation command.

## Research and data notes

There is no retailer integration or sourced market dataset in this package. Product listings and histories in `data/products.json` and generated training observations are synthetic. This makes the project runnable without credentials and prevents demo estimates from being mistaken for verified retail facts. A production study should establish a permitted data source, document category and time coverage, deduplicate products and sellers, normalize variants and currencies, then use time-aware model evaluation.

## Architecture

The browser serves a responsive HTML/CSS/JavaScript interface from Flask. The interface calls the JSON API in `app.py`; `database.py` owns SQLite schema, one-time catalog migration and repository queries; `pricing.py` owns fair-price comparison, score weights, thresholds and explanations; `ml/price_model.py` owns model training, loading, prediction and evaluation. SQLite stores product rows, time-stamped price history, watchlist membership and recent analysis activity. `data/products.json` remains the portable seed catalog.

## Next research steps

- Interview shoppers about how they judge reference prices and discount labels.
- Compare established price-history and deal-tracking products to identify trust and explainability gaps.
- Source legally reusable, time-stamped data and state the geography, period, currency and cleaning rules.
- Compare interpretable baseline regression with tree-based models using a time-based holdout.
- Validate the explanations and score thresholds with users before treating them as decision guidance.